# Coconut Coir E-Commerce (CodeIgniter 4) Setup Guide

## Default Accounts
- Seller: `seller@coircraft.local` / `Seller123!`
- Buyer: `buyer@coircraft.local` / `Buyer123!`

## 1) Prerequisites
- PHP `8.2+`
- Composer
- MySQL/MariaDB (`5.7+` or `8+`)
- XAMPP (optional, for local Apache/MySQL)

## 2) Project Location
- `c:\Users\dwayn\Downloads\EC+HCI Project\coconutcoir-shop`

## 3) Free Local DB Setup + Port Fix (Windows)
If port `3306` is already occupied, identify and kill the process first:

```powershell
netstat -ano | findstr :3306
taskkill /PID <PID_FROM_NETSTAT> /F
```

Then:
1. Start MySQL from XAMPP or your local MySQL service.
2. Create database `coconutcoir_shop` with collation `utf8mb4_general_ci`.

## 4) Configure `.env`
From project root:
1. Copy `env` to `.env`.
2. Set:

```ini
CI_ENVIRONMENT = development
app.baseURL = 'http://localhost:8080/'

database.default.hostname = localhost
database.default.database = coconutcoir_shop
database.default.username = root
database.default.password =
database.default.DBDriver = MySQLi
database.default.port = 3306
```

## 5) Install + Migrate + Seed
Run in project root:

```bash
composer install
php spark migrate
php spark db:seed InitialSeeder
```

If you previously ran old migrations and want a clean schema:

```bash
php spark migrate:refresh
php spark db:seed InitialSeeder
```

## 6) Database Features Included
The schema now includes:
- `products.sold_count`
- `products.additional_details`
- `products.release_date`
- richer `orders` breakdown fields:
  - `subtotal_amount`
  - `shipping_fee`
  - `voucher_code`
  - `voucher_type`
  - `voucher_discount_amount`
  - `shipping_address`
- `vouchers` table (seeded with):
  - `FREESHIP` (free shipping)
  - `LESS5` (5% off)
  - `LESS10` (10% off)
- `product_reviews` table (`user_id + product_id` unique)
- `storefront_settings` supports:
  - `title`
  - `description`
  - `hero_background_image`

## 7) Run Locally

```bash
php spark serve
```

Open: `http://localhost:8080/`

## 8) Feature Checklist
### Buyer
- Home page includes:
  - announcement marquee strip
  - configurable hero title/description/background image
  - featured product tiles with quick cart add
- Product cards show:
  - stock
  - sold count
  - latest review (or `No product reviews`)
- Product detail page: `/products/{id}`
- Product detail page can show seller-managed `Details` content
- Cart shows item images and split layout
- Checkout has:
  - item list + order summary in separate containers
  - address selection (auto-reuse from previous orders)
  - voucher entry + voucher type details
  - shipping fee + full breakdown
  - payment methods: COD, credit/debit card, e-wallet
- Transactions show item images and review form with 5-star picker

### Seller
- Storefront management: `/seller/storefront`
  - configurable `Title`, `Description`, `Hero Background Image URL`, and `Announcement`
- Inventory: `/seller/inventory`
  - create/edit products with `Additional Details` and `Release Date`
- Reports: `/seller/reports`

## 8.1) New Migration Reminder
If you already migrated before these latest visual/data updates, run:

```bash
php spark migrate
```

If your schema is old or inconsistent:

```bash
php spark migrate:refresh
php spark db:seed InitialSeeder
```

## 9) Free Deployment Recommendation (No Railway)
### Recommended for this project: InfinityFree (PHP + MySQL shared hosting)
This CodeIgniter 4 app works on standard Apache + PHP + MySQL hosting.

Why this is the best free path for your use case:
- free for school/non-commercial use
- supports PHP + MySQL + phpMyAdmin
- no need for Railway credits

Important clarification:
- `phpMyAdmin` is only a database GUI.
- Your local XAMPP database (`127.0.0.1`) is local-only and cannot be used directly by a public site unless your PC is always on and exposed to the internet (not recommended).
- For deployment, create a cloud MySQL database in your hosting account and import your schema/data there.

### InfinityFree Deployment Steps (Detailed)

#### A) Prepare GitHub repo (source of truth)
If your repo is not yet pushed:

```bash
git init
git add .
git commit -m "Initial Coconut Coir shop commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

If already connected, use for future updates:

```bash
git add .
git commit -m "Describe your change"
git push
```

#### B) Create free hosting + MySQL database
1. Create an InfinityFree account and create a hosting account.
2. Create a free subdomain (or connect a domain).
3. Open hosting control panel.
4. Create a MySQL database.
5. Save these values from the control panel:
   - database host
   - database name
   - database username
   - database password
   - database port (usually `3306`)
6. Open the hosted phpMyAdmin from the same control panel and confirm you can log in.

#### C) Build the deploy package locally
From project root:

```bash
composer install --no-dev --optimize-autoloader
```

Use this folder structure on hosting (recommended for CI4 security):
- app core (private): `/ci4app`
- web root (public): `/htdocs` (or `/public_html` on some hosts)

Upload files as follows:
1. Upload project root files/folders to `/ci4app`, except the contents of `public/`.
2. Upload everything inside `public/` to `/htdocs`.
3. Ensure `/htdocs/.htaccess` exists (from `public/.htaccess`).

#### D) Fix `index.php` path for shared hosting
In `/htdocs/index.php`, change the `Paths.php` include line to point to your private app folder.

Example:

```php
require FCPATH . '../ci4app/app/Config/Paths.php';
```

If your folders are named differently, adjust the relative path accordingly.

#### E) Configure production `.env` on hosting
1. In `/ci4app`, copy `env` to `.env` (if `.env` is missing).
2. Set:

```ini
CI_ENVIRONMENT = production
app.baseURL = 'https://<your-domain>/'

database.default.hostname = <hosted-mysql-host>
database.default.database = <hosted-mysql-database>
database.default.username = <hosted-mysql-username>
database.default.password = <hosted-mysql-password>
database.default.DBDriver = MySQLi
database.default.port = 3306
```

3. Remove leading `#` on these lines if they are commented.

#### F) Create tables + data in hosted MySQL
Most free shared hosts do not provide full SSH access for `php spark`, so use SQL export/import.

1. On local machine (XAMPP DB), run your latest schema/data setup first:

```bash
php spark migrate
php spark db:seed InitialSeeder
```

2. In local phpMyAdmin, export the full SQL of `coconutcoir_shop`.
3. Open hosted phpMyAdmin (InfinityFree), select your hosted database, then import that SQL file.
4. Confirm tables exist after import (for example: `users`, `products`, `orders`, `vouchers`, `product_reviews`, `storefront_settings`).

> You can use MySQL Workbench instead of phpMyAdmin for import if you prefer. The requirement is the same: import schema/data into the hosted MySQL database, not local XAMPP.

#### G) Verify production works
1. Visit `https://<your-domain>/`.
2. Login using seeded test accounts.
3. Verify:
   - product list loads
   - product detail page opens
   - cart/checkout works
   - order placement works
   - seller pages load

#### H) Common issues and exact fixes
1. `500 Internal Server Error` right after upload:
   - Re-check `/htdocs/index.php` path to `../ci4app/app/Config/Paths.php`.
2. Database connection errors:
   - Verify hosted DB credentials in `/ci4app/.env` (host/user/password/name).
   - Ensure you are not using `localhost` unless your host explicitly says so.
3. Site CSS/images missing:
   - Confirm `app.baseURL` ends with `/` and uses your exact domain.
4. App works locally but not online:
   - Ensure all CI4 private folders (`app`, `system`, `writable`, `vendor`) are in `/ci4app` and only `public` contents are in `/htdocs`.

## 10) Notes
- Footer disclaimer remains:
  - `For educational purposes only, and no copyright infringement is intended.`
